# --- START OF FILE casery.py ---
import os

# -- IMPORTANT --
# The following values should be set as environment variables for security.
# Example:
# bot_token = os.getenv("BOT_TOKEN")
# bot_token2 = os.getenv("SESSION_STRING")

## مطورين السورس (Sudo users of the maker bot)
caes = ["Fox_fv", "zozooryy", "@cyv0we"]  # Add your main developer usernames here

## يوزر المطور الاساسي (The main developer's username)
casery = os.getenv("OWNER_USERNAME", "TI_1Too")

## ايدي مطور السورس الاساسي (The main developer's user ID)
caserid = int(os.getenv("OWNER_ID", "6908157965"))

## اسم البوتات بالعربى (Default bot name)
OWNER = os.getenv("BOT_NAME_AR", "النسور")

## اسمك&الميوزك (Music text)
muusiic = os.getenv("MUSIC_TEXT", "SOURCE Titanx")

## اسم السورس ع صوره التشغيل (Source name on image)
suorce = os.getenv("SOURCE_NAME_IMG", "SOURCE Titanx")

## قناه السورس (Source channel link)
source = os.getenv("SOURCE_CHANNEL_LINK", "https://t.me/fox68899")
ch = os.getenv("SOURCE_CHANNEL_USER", "fox68899")

## جروب السورس (Source group link)
group = os.getenv("SOURCE_GROUP_LINK", "https://t.me/fox68899")

## لوجو السورس(صوره السورس) (Source logo URL)
photosource = os.getenv("SOURCE_PHOTO_URL", "https://envs.sh/ws4.webp")

## توكن الصانع (Maker Bot Token)
bot_token = os.getenv("BOT_TOKEN", "8190727627:AAFurLfneMl9KGSx7pdY84pTJVw_mxaYlxE")

## جلسه الاشتراك (Helper Account Session String)
bot_token2 = os.getenv("SESSION_STRING", "BAGHeQMAQFDc6TAIweY7uD5nxSOa2MyJ_nZVzaPAd6VVtId_Ij8SHiwzmgNbboOSvtVXekosc8rBllmxd1_YVD5oPaKiN70UFr-yFIxKbyX5TJ0ZNUbu0RQy4CstT_XhkjNLtuOnKVoU8dL_dqUghscOan2JPJUWJnLAygYs6hjs-ILXSkYDHYF5SfXCN_fe94l7fqjMEZYwNUZ80IYl5b6_uP5HDw8c90P6VC-BDhEky41CoQ8caKPmvBrFRPuTyjkQfxaZkEmA3oje1QpZCU8xe9Efy-tmmY3wX8vl5OOHoQ6YVkvKBAMrgs9EK5VqtQT4vVXuigkR3MjdcdDF7IWXFzmhsAAAAAHJH68ZAA")
# --- END OF FILE casery.py ---